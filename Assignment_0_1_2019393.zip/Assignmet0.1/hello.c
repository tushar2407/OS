#include <stdio.h>
int main(){
    int a=0,b=1;
    printf(" a=%d \n b=%d", a, b);
    return 0;
}