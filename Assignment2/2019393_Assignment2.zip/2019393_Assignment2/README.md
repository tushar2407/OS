# OS-Assignment-2

## Do not add any extra files. Stricly follow the format given below.

## Fill your Name and Roll_number field in the top of every C file.

## Instructions for Question-1
1. Use Q1_part1.c for fork()
2. Use Q1_part2.c for pthreads
3. Add to the given Makefile for code compilation. (We will only run the predefined targets)
4. Sumbit the writeup as writeup.pdf


## Instructions for Question-2
1. Copy your diff in the given diff.txt (No screenshots or pdfs are accepted)
2. Use test.c to test your implemented syscall and error handling
3. You don't need to change the Makefile provided.
4. Submit the writeup as writeup.pdf
