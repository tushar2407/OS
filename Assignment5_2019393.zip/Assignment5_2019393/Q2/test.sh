#!/bin/sh
gnome-terminal  -e ./a.out & gnome-terminal  -e ./a.out  